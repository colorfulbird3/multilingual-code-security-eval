public UserPreferences loadConfiguration(String xmlData)
public UserPreferences loadUserPreferences(String xmlData)