package com.example.datamodel.service;

import com.example.datamodel.model.UserProfile;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;

/**
 * Diensklas vir die verwerking van gebruikersprofieldata.
 * Hierdie klas is verantwoordelik vir die ontleding van XML-data na 'n UserProfile-objek.
 */
public class DataProcessingService {

    /**
     * Verwerk 'n XML-string wat gebruikersprofieldata bevat en deserialiseer dit na 'n UserProfile-objek.
     *
     * @param xmlData Die XML-string wat die gebruikersprofieldata bevat
     * @return 'n UserProfile-objek wat uit die XML-data onttrek is
     * @throws IllegalArgumentException as die XML-data ongeldig is of nie ontleed kan word nie
     */
    public UserProfile processUserProfile(String xmlData) {
        if (xmlData == null || xmlData.trim().isEmpty()) {
            throw new IllegalArgumentException("XML-data mag nie nul of leeg wees nie");
        }

        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(UserProfile.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            StringReader reader = new StringReader(xmlData);
            return (UserProfile) unmarshaller.unmarshal(reader);
        } catch (JAXBException e) {
            throw new IllegalArgumentException("Kon nie XML-data ontleed nie: " + e.getMessage(), e);
        }
    }
}