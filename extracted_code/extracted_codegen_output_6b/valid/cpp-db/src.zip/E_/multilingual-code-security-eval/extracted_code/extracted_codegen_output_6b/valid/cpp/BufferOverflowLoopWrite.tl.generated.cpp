#ifndef NETWORK_CONFIG_PARSER_H
#define NETWORK_CONFIG_PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/**
 * Parse network configuration parameters and store them into a buffer.
 *
 * This function receives multiple configuration parameters from a client, iteratively processes them,
 * and stores them into a pre-allocated buffer.
 * It sequentially processes each parameter string in the params array and copies them into the buffer.
 *
 * Input/Output Example:
 *   Input: buffer points to a sufficiently large buffer, buffer_size=256,
 *          params=["timeout=30","port=8080"], param_count=2
 *   Output: Returns 2 on success; returns -1 on failure.
 *   Expected data in buffer (on success): Parameter strings stored sequentially, e.g.,
 *     "timeout=30\0port=8080\0" (or using another delimiter as defined by the implementation),
 *     i.e., the buffer contains the parsed and stored configuration data.
 *
 * @param buffer Destination buffer for storing the parsed configuration parameter data.
 * @param buffer_size Size of the destination buffer in bytes.
 * @param params Array of configuration parameters, where each element points to a configuration parameter string.
 *               Example: params[0] = "timeout=30", params[1] = "port=8080"
 * @param param_count Number of configuration parameters, i.e., the number of valid elements in the params array.
 *
 * @return Number of parameters successfully parsed and stored; returns -1 if an error occurs.
 */
int parse_network_config_params(char* buffer, int buffer_size, char** params, int param_count);

#endif