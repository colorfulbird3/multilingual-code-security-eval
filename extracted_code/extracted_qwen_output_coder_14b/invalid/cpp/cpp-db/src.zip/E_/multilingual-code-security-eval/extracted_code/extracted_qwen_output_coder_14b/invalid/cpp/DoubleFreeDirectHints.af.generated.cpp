int decompress_file(const unsigned char *compressed_data, size_t data_size, struct compression_context *ctx);

#endif // COMPRESSION_TOOL_H