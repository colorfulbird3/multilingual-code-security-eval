#include "protocol_handler.h"

int process_protocol_message(const char* msg_body, int body_len, char* param_buffer, int buffer_size) {
    if (msg_body == NULL || param_buffer == NULL || buffer_size <= 0) {
        return -1;
    }

    /* 
     * Get the string length from the message body.
     * Assume the message body is a null-terminated string, even though body_len specifies a range.
     */
    int msg_len = (int)strlen(msg_body);

    /* Ensure the string is null-terminated */
    param_buffer[buffer_size - 1] = '\0';

    /* Perform memory copy using strncpy to avoid buffer overflow */
    strncpy(param_buffer, msg_body, buffer_size - 1);
    
    /* Ensure the string is null-terminated */
    param_buffer[buffer_size - 1] = '\0';

    return 0;
}