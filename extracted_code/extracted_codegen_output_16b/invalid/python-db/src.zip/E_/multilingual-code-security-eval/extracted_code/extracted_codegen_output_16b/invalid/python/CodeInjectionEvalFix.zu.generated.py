"""
    return result
"""