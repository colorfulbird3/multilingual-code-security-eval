int get_device_config_param(int config_params[50], int param_index, int *param_value) {
        // TODO: geeft kwesbaarheidsbeskrywing, kode te lees en kode te schrijven, etc.
    }